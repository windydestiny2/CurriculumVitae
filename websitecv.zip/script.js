
console.log("Portfolio page loaded!");
